#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
int main(int argc, char *argv[]){
	int rows = 0;
	int columns = 0;
	int a, b;

	rows = atoi(argv[1]);
	columns = atoi(argv[2]);
	
	int pipefd[columns][2];
	int *A = (int *) malloc((rows * columns) * sizeof(int)); 
	
	printf("Enter the matrix elements:\n");
	for (a = 0; a < columns; a++) {
		for (b = 0; b < rows; b++) {
			printf("A[%d,%d] = ", a, b);
			scanf("%d", A + a * rows + b);
		}
		printf("\n");
	}

	int x = 0;
	printf("Enter a number:");
	scanf("%d", &x);

	for(int a = 0; a < columns; ++a){
	    pipe(pipefd[a]);
		pid_t pid = fork();
		
		    if (pid == -1){
                printf("parent PID: %d \n", getpid());
			    for (b = 0; b < rows; b++) {
				    *(A + a * rows + b) = x * (*(A + a * rows + b));
				    printf("%d * A[%d,%d] = %d\n", x, a, b, *(A + a * rows + b));				
			    }
		    }
		
		else if (pid == 0) {             
			printf("child%d PID: %d \n", a, getpid()); 

			close(pipefd[a][0]);
            
			for (b = 0; b < rows; b++) {
				*(A + a * rows + b) = x * (*(A + a * rows + b));
				printf("%d * A[%d,%d] = %d\n", x, a, b, *(A + a * rows + b));				
			}

			write(pipefd[a][1], A, sizeof(A)* columns * rows);

			exit(0);
		} 
 
            close(pipefd[a][1]); 

            read(pipefd[a][0], A, sizeof(A)* columns * rows);
		}
	
	wait(0);
	printf("Final matrix elements:\n");
	
	for (a = 0; a < columns; a++) {
		for (b = 0; b < rows; b++) {
			printf("A[%d,%d] = %d\n", a, b, *(A + a * rows + b));		
		}
		printf("\n");
	}

	exit(0);
}
