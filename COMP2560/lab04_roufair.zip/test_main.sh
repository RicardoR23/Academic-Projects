#!/bin/bash
echo "start building main program:"
echo "compiling to assembly lines ..."
cc main.c -S 
cc increment.c -S
echo "translating to opcodes ..."
cc main.s -c
cc increment.s -c
echo "statically linking all required opcodes ..."
cc main.o increment.o -o main
echo "build successfully done!"

User_Input=0
Output=0
Expected_Output=0

passed=0
failed=0

while read input
do 

    User_Input=$input
    Output=$(./main <<< $input)
    Expected_Output=${input#*,}

    if [[ $Output -eq $User_Input ]] 2> /dev/null; then let passed=passed+1
    echo "input: ${User_Input%,*}, main: $Output, correct: $Expected_Output ==> passed"

    else let failed=failed+1
    echo "input: ${User_Input%,*}, main: $Output, correct: $Expected_Output ==> failed"
    fi

done < "./test_inputs.txt"

	echo 
	echo test passed: "$passed"
	echo test failed: "$failed"
