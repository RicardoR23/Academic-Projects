#include <stdlib.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>


int main(int argc, char* argv[]){

			int num, num2, size, sum, fd;
			char userName[100];
		    char passWord[100];
		    		char serverMessage[] = "authentication failed!\n";	
		    
    setbuf(stdout, NULL);
	int domain = AF_INET;//Network Protocol: TCP/IP
	int type = SOCK_STREAM;//Connection-Oriented
	int protocol = 0;//Default transport: TCP for Internet connection-oriented

	int server_sd;//socket descriptor ~= file descriptor
	server_sd = socket(domain, type, protocol);
	if (server_sd == -1){
		printf("error in creating socket for The Server!\n");
		exit(1);
	}
	else
		printf("socket has created for The Server  with sd:%d\n", server_sd);

	//Binding to an address is a must for The Server!
	struct in_addr server_sin_address;
	server_sin_address.s_addr = inet_addr(argv[1]);//nslookup `hostname`
	int server_sin_port = htons(atoi(argv[2]));//larger than 1024

	struct sockaddr_in server_sin;
	server_sin.sin_family = domain;
	server_sin.sin_addr = server_sin_address;
	server_sin.sin_port = server_sin_port;
	int result = bind(server_sd, (struct sockaddr *) &server_sin, sizeof(server_sin));
	if (result == -1){
		printf("error in binding The Server to the address:port = %d:%d\n", server_sin.sin_addr, server_sin.sin_port);
		exit(1);
	}
	else
		printf("The Server bound to the address:port = %d:%d\n", server_sin.sin_addr, server_sin.sin_port);

	//The Server ready to receive calls (up to 5 calls. More are rejected!) 
	if (listen(server_sd, 5) < 0) {
		perror("The Server's listening failed!\n");
		exit(1);
	}

	struct sockaddr_in client_sin;//I want to know who send the message
			
		int client_sin_len = sizeof(client_sin);
		
		    while(1){

        result = accept(server_sd, (struct sockaddr *) &client_sin, &client_sin_len);
        
		        if (result == -1){
			        printf("error in opening the request from client %d:%d !\n", client_sin.sin_addr, client_sin.sin_port);
		        }
		        else{
		        		        
			        printf("The Server opened the request from client %d:%d\n", client_sin.sin_addr, client_sin.sin_port);
			        
			        if ((fd = fork())<0){
			        printf("Error");
			        } else if (fd == 0){
			        break;
			        }
			    }
			}
			


    
    while(1){
    
        recv(result, &num, sizeof(num), 0);
        recv(result, &num2, sizeof(num2), 0);
    
        recv(result, &size, sizeof(int), 0);
        recv(result, userName, size, 0);
        recv(result, &size, sizeof(int), 0);
        recv(result, passWord, size, 0);

		if ((strcmp("comp2560", userName) == 0) || (strcmp("f2022", passWord) == 0)){
		int fd2 = fork();
	    
	    if (fd2 == -1){
	    printf("Error creating child");
	    } else if (fd2 > 0){
	    wait(0);
	    } else{
	    
	    sum = num + num2;
	    size = sizeof(int);
	    
	    send(result, &size, sizeof(int), 0);    
	    send(result, &sum, sizeof(int), 0);  
	    
	    exit(1); 
	    }
	
	    }     
	    else if ((strcmp("comp2560", userName) != 0) || (strcmp("f2022", passWord) != 0)){
	    size = 23;
		send(result, &size, sizeof(int), 0);	
		send(result, serverMessage, 23, 0);	    
}
}
}



