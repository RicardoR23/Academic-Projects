#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void main(){

	int fd_in=open("/dev/pts/6", O_RDONLY);
	int fd_out=open("log.txt", O_CREAT |  O_RDWR, 0666 | O_TRUNC, 0666);

	char buf[20];
	ssize_t bytes_read;

	while ((bytes_read = read(fd_in, buf, sizeof(buf))) > 0){
	
	write(fd_out, "block read: \n<", 14);
	write(fd_out, buf, bytes_read-1);
	write(fd_out, ">\n", 2);

		if(buf[0] == 'E' && buf[1] == 'N' && buf[2] == 'D'){
			if(bytes_read > 4){
				continue;
			} else{
				break;
				}
			}
		}
	
close(fd_out);
}
