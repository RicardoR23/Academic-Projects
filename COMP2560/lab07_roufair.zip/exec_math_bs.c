#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    printf("system_bootstrap pid:%d\n", getpid());
    char *program =
        "#include <stdio.h>\n"
        "#include <stdlib.h>\n"
        "#include <unistd.h>\n"

        "int result;\n"
        "int main(int argc, char *argv[]){\n"
        "printf(\"math pid: %d\\n\", getpid());\n"

        "int a = 0;\n"
        "int b = 0;\n"
        "char * operator = argv[0];\n"
        "a = atoi(argv[1]);\n"
        "b = atoi(argv[2]);\n"

	"switch(operator[0]){\n"

        "case '+':\n"
        "result = a + b;\n"
        "printf(\"%d + %d = %d\\n\", a, b, result);\n"
	"break;\n"

        "case '-':\n"
        "result = a - b;\n"
        "printf(\"%d - %d = %d\\n\", a, b, result);\n"
	"break;\n"

        "case '*':\n"
        "result = a * b;\n"
        "printf(\"%d * %d = %d\\n\", a, b, result);\n"
	"break;\n"

        "default:\n"
        "result = a / b;\n"
        "printf(\"%d / %d = %d\\n\", a, b, result);\n"
    "break;\n"

        "return 0;\n"
        "}\n"
    "}\n";


    int fd = open("./math.c", O_RDWR | O_CREAT | O_TRUNC, 0666);
    printf("fd for math.c file:%d\n", fd);
    write(fd, program, strlen(program));
    
    int process;
    extern char** environ;
    
    if ((process = fork()) < 0) {
        printf("ERROR");
    }
    
    if(process >= 0){
        if (process > 0){

            int fd2 = open("/usr/bin/cc", O_RDONLY);
            char* compile_argv[] = {"/usr/bin/cc", "math.c", "-o", "math", NULL};
            fexecve(fd2, compile_argv, environ);
        }
        else {

            char* child_argv[] = {argv[1], argv[2], argv[3], NULL};
            int fd3 = open("math", O_RDONLY);
            fexecve(fd3, child_argv, environ);
        }
    }

}
