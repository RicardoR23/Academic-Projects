# Grading Checklist Mapping

## 1. Business case paragraph
- `about.php`

## 2. 20 products with 2 options each
- `sql/schema.sql`
- `catalog.php`
- `product.php`

## 3. 3 dynamic site templates + ability to change
- `assets/css/style.css`
- `admin/settings.php`
- `theme-preview.php`

## 4. Dynamic HTML forms on at least two pages
- `quote.php`
- `support.php`

## 5. PHP code and MySQL database documented
- comments in PHP files
- `docs/DATABASE-DESIGN.md`
- `docs/INSTALL.md`

## 6. Code comments
- present throughout PHP/CSS/JS files

## 7. 5 help wiki pages + context help links
- `help/index.html`
- `help/site-tour.html`
- `help/shopping-guide.html`
- `help/account-and-orders.html`
- `help/admin-guide.html`
- `help/troubleshooting.html`
- Context help chip in `includes/header.php`

## 9. Responsive menu
- `includes/header.php`
- `assets/css/style.css`
- `assets/js/app.js`

## 10. 20 dynamic pages, 1 CSS, 1 JS, 20 images, 3 video/audio files, update instructions
- dynamic pages: all public/admin PHP plus `product-01.php` to `product-20.php`
- CSS: `assets/css/style.css`
- JS: `assets/js/app.js`
- images: `assets/img/products/product-01.svg` ... `product-20.svg`
- media: `assets/media/showcase-1.mp4` ... `showcase-3.mp4`, `audio-1.wav` ... `audio-3.wav`
- update instructions: `help/shopping-guide.html`

## 11. Live link
- upload to `myweb.cs.uwindsor.ca`

## 12. Advanced CSS
- `assets/css/style.css`

## 13. SEO tags
- `includes/header.php`
- `sitemap.php`
- `robots.txt`
